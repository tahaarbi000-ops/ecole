// ---------------------------------------------------------------------------
// Dummy data — Registre scolaire (entrées, sorties, absences, retards,
// observations). À remplacer plus tard par src/services/api.js
// (getRegisterEntries, getRegisterExits, getAbsences, getLateRecords, getObservations).
// ---------------------------------------------------------------------------

export const movementTypes = ['Élève', 'Enseignant', 'Surveillant', 'Employé', 'Visiteur'];

export const registerEntries = [
  { id: 1, date: '2026-08-10', heure: '07:52', nom: 'Ben Ali', prenom: 'Mohamed', type: 'Élève', remarque: '' },
  { id: 2, date: '2026-08-10', heure: '07:58', nom: 'Khemiri', prenom: 'Leila', type: 'Enseignant', remarque: 'Cours de 8h' },
  { id: 3, date: '2026-08-10', heure: '08:05', nom: 'Trabelsi', prenom: 'Ahmed', type: 'Élève', remarque: '' },
  { id: 4, date: '2026-08-10', heure: '08:10', nom: 'Rekik', prenom: 'Foued', type: 'Surveillant', remarque: '' },
  { id: 5, date: '2026-08-11', heure: '07:49', nom: 'Mansouri', prenom: 'Sarra', type: 'Élève', remarque: '' },
  { id: 6, date: '2026-08-11', heure: '08:15', nom: 'Fournisseur Papeterie', prenom: 'M.', type: 'Visiteur', remarque: 'Livraison fournitures' },
  { id: 7, date: '2026-08-11', heure: '07:55', nom: 'Gharbi', prenom: 'Walid', type: 'Enseignant', remarque: '' },
  { id: 8, date: '2026-08-12', heure: '08:02', nom: 'Ben Salah', prenom: 'Mariem', type: 'Élève', remarque: '' },
  { id: 9, date: '2026-08-12', heure: '09:30', nom: 'Parent — Ben Amor', prenom: 'Tarek', type: 'Visiteur', remarque: 'Rendez-vous direction' },
  { id: 10, date: '2026-08-12', heure: '07:47', nom: 'Belhadj', prenom: 'Chaima', type: 'Employé', remarque: '' },
];

export const registerExits = [
  { id: 1, date: '2026-08-10', heure: '13:02', nom: 'Ben Ali', prenom: 'Mohamed', type: 'Élève', remarque: 'Sortie normale' },
  { id: 2, date: '2026-08-10', heure: '13:10', nom: 'Khemiri', prenom: 'Leila', type: 'Enseignant', remarque: '' },
  { id: 3, date: '2026-08-10', heure: '11:30', nom: 'Trabelsi', prenom: 'Ahmed', type: 'Élève', remarque: 'Rendez-vous médical' },
  { id: 4, date: '2026-08-11', heure: '13:05', nom: 'Mansouri', prenom: 'Sarra', type: 'Élève', remarque: 'Sortie normale' },
  { id: 5, date: '2026-08-11', heure: '10:45', nom: 'Fournisseur Papeterie', prenom: 'M.', type: 'Visiteur', remarque: '' },
  { id: 6, date: '2026-08-11', heure: '16:20', nom: 'Gharbi', prenom: 'Walid', type: 'Enseignant', remarque: '' },
  { id: 7, date: '2026-08-12', heure: '13:00', nom: 'Ben Salah', prenom: 'Mariem', type: 'Élève', remarque: 'Sortie normale' },
  { id: 8, date: '2026-08-12', heure: '10:10', nom: 'Parent — Ben Amor', prenom: 'Tarek', type: 'Visiteur', remarque: '' },
  { id: 9, date: '2026-08-12', heure: '16:00', nom: 'Belhadj', prenom: 'Chaima', type: 'Employé', remarque: '' },
];

export const absenceMotifs = [
  'Maladie',
  'Rendez-vous médical',
  'Raison familiale',
  'Non justifiée',
  'Autre',
];

export const absences = [
  { id: 1, eleve: 'Yassine Jlassi', niveau: '2ème année', date: '2026-08-10', motif: 'Maladie', justifiee: true },
  { id: 2, eleve: 'Aya Gharbi', niveau: 'Préscolaire', date: '2026-08-10', motif: 'Rendez-vous médical', justifiee: true },
  { id: 3, eleve: 'Omar Hamdi', niveau: '7ème année', date: '2026-08-11', motif: 'Non justifiée', justifiee: false },
  { id: 4, eleve: 'Salma Ferjani', niveau: '5ème année', date: '2026-08-11', motif: 'Raison familiale', justifiee: true },
  { id: 5, eleve: 'Youssef Guesmi', niveau: '8ème année', date: '2026-08-11', motif: 'Non justifiée', justifiee: false },
  { id: 6, eleve: 'Ranim Sassi', niveau: '4ème année', date: '2026-08-12', motif: 'Maladie', justifiee: true },
  { id: 7, eleve: 'Malek Jaziri', niveau: '9ème année', date: '2026-08-12', motif: 'Autre', justifiee: false },
  { id: 8, eleve: 'Lina Chebbi', niveau: '2ème année', date: '2026-08-13', motif: 'Rendez-vous médical', justifiee: true },
  { id: 9, eleve: 'Cyrine Toumi', niveau: '7ème année', date: '2026-08-13', motif: 'Non justifiée', justifiee: false },
  { id: 10, eleve: 'Hamza Belhadj', niveau: '8ème année', date: '2026-08-14', motif: 'Maladie', justifiee: true },
];

export const lateRecords = [
  { id: 1, eleve: 'Rayen Kilani', heureArrivee: '08:22', retard: 22, justifiee: false },
  { id: 2, eleve: 'Ines Bouazizi', heureArrivee: '08:15', retard: 15, justifiee: true },
  { id: 3, eleve: 'Firas Bouzid', heureArrivee: '08:40', retard: 40, justifiee: false },
  { id: 4, eleve: 'Anis Rekik', heureArrivee: '08:10', retard: 10, justifiee: true },
  { id: 5, eleve: 'Nour Ben Amor', heureArrivee: '08:35', retard: 35, justifiee: false },
  { id: 6, eleve: 'Amine Cherni', heureArrivee: '08:12', retard: 12, justifiee: true },
  { id: 7, eleve: 'Mariem Ben Salah', heureArrivee: '08:25', retard: 25, justifiee: false },
  { id: 8, eleve: 'Mohamed Ben Ali', heureArrivee: '08:08', retard: 8, justifiee: true },
];

export const observationTypes = ['Positive', 'Négative', 'Neutre'];

export const observations = [
  {
    id: 1,
    date: '2026-08-10',
    concerne: 'Yassine Jlassi — 2ème année',
    type: 'Positive',
    auteur: 'Mohamed Ben Ali',
    observation: 'Très bonne participation en classe de mathématiques.',
  },
  {
    id: 2,
    date: '2026-08-10',
    concerne: 'Omar Hamdi — 7ème année',
    type: 'Négative',
    auteur: 'Foued Rekik',
    observation: 'Comportement perturbateur pendant la récréation.',
  },
  {
    id: 3,
    date: '2026-08-11',
    concerne: 'Salma Ferjani — 5ème année',
    type: 'Positive',
    auteur: 'Leila Khemiri',
    observation: 'Excellent travail sur le projet de français.',
  },
  {
    id: 4,
    date: '2026-08-11',
    concerne: 'Classe 6ème année',
    type: 'Neutre',
    auteur: 'Direction',
    observation: 'Sortie pédagogique prévue le mois prochain — information transmise aux parents.',
  },
  {
    id: 5,
    date: '2026-08-12',
    concerne: 'Youssef Guesmi — 8ème année',
    type: 'Négative',
    auteur: 'Sonia Mansouri',
    observation: 'Absences répétées non justifiées à signaler aux parents.',
  },
  {
    id: 6,
    date: '2026-08-13',
    concerne: 'Ranim Sassi — 4ème année',
    type: 'Positive',
    auteur: 'Walid Gharbi',
    observation: 'Progrès notable en sciences ce trimestre.',
  },
];

import { useMemo, useState } from 'react';
import { Box, Button, HStack, Select, Badge, IconButton, Tooltip, useToast, useDisclosure, Text, Wrap } from '@chakra-ui/react';
import { Pencil, Trash2, LogIn, LogOut } from 'lucide-react';
import SearchBar from '../common/SearchBar';
import DataTable from '../common/DataTable';
import ConfirmDialog from '../common/ConfirmDialog';
import MovementFormModal from './MovementFormModal';
import { movementTypes } from '../../data/register';

const TYPE_COLORS = {
  Élève: { bg: 'brand.50', color: 'brand.700' },
  Enseignant: { bg: 'accent.50', color: 'accent.500' },
  Surveillant: { bg: 'warning.50', color: 'warning.500' },
  Employé: { bg: 'positive.50', color: 'positive.600' },
  Visiteur: { bg: 'ink.100', color: 'ink.700' },
};

function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('fr-FR');
}

/**
 * Page générique pour les Entrées et Sorties du registre (structure identique,
 * seul le libellé et l'icône changent).
 * @param {'entry'|'exit'} direction
 */
export default function MovementPage({ direction, initialData }) {
  const toast = useToast();
  const [movements, setMovements] = useState(initialData);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [selected, setSelected] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const formModal = useDisclosure();
  const deleteDialog = useDisclosure();

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return movements.filter((m) => {
      const matchesSearch = !term || `${m.nom} ${m.prenom} ${m.remarque}`.toLowerCase().includes(term);
      const matchesType = !typeFilter || m.type === typeFilter;
      return matchesSearch && matchesType;
    });
  }, [movements, search, typeFilter]);

  const openAdd = () => { setSelected(null); formModal.onOpen(); };
  const openEdit = (m) => { setSelected(m); formModal.onOpen(); };
  const askDelete = (m) => { setToDelete(m); deleteDialog.onOpen(); };

  const handleSubmit = (formData) => {
    setIsSaving(true);
    setTimeout(() => {
      if (selected) {
        setMovements((prev) => prev.map((m) => (m.id === selected.id ? { ...m, ...formData } : m)));
        toast({ title: 'Mouvement modifié', status: 'success', duration: 3000, isClosable: true });
      } else {
        const newMovement = { ...formData, id: Math.max(0, ...movements.map((m) => m.id)) + 1 };
        setMovements((prev) => [newMovement, ...prev]);
        toast({ title: direction === 'entry' ? 'Entrée enregistrée' : 'Sortie enregistrée', status: 'success', duration: 3000, isClosable: true });
      }
      setIsSaving(false);
      formModal.onClose();
    }, 600);
  };

  const handleDelete = () => {
    setIsDeleting(true);
    setTimeout(() => {
      setMovements((prev) => prev.filter((m) => m.id !== toDelete.id));
      toast({ title: 'Mouvement supprimé', status: 'info', duration: 3000, isClosable: true });
      setIsDeleting(false);
      deleteDialog.onClose();
      setToDelete(null);
    }, 500);
  };

  const columns = [
    { key: 'date', label: 'Date', sortable: true, render: (row) => formatDate(row.date) },
    { key: 'heure', label: 'Heure', sortable: true },
    { key: 'nom', label: 'Nom', sortable: true },
    { key: 'prenom', label: 'Prénom', sortable: true },
    {
      key: 'type',
      label: 'Type',
      sortable: true,
      render: (row) => {
        const c = TYPE_COLORS[row.type] || { bg: 'ink.100', color: 'ink.700' };
        return <Badge bg={c.bg} color={c.color} borderRadius="full" px={2.5}>{row.type}</Badge>;
      },
    },
    { key: 'remarque', label: 'Remarque', render: (row) => row.remarque || <Text color="ink.400">—</Text> },
  ];

  return (
    <Box>
      <Wrap spacing={3} mb={5} align="center">
        <SearchBar value={search} onChange={setSearch} placeholder="Rechercher par nom, prénom, remarque…" />
        <Select
          w={{ base: 'full', sm: '180px' }}
          size="sm"
          borderRadius="lg"
          bg="white"
          borderColor="ink.200"
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
        >
          <option value="">Tous les types</option>
          {movementTypes.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </Select>
        {(search || typeFilter) && (
          <Button size="sm" variant="ghost" onClick={() => { setSearch(''); setTypeFilter(''); }}>
            Réinitialiser
          </Button>
        )}
        <HStack spacing={1.5} ml="auto" color="ink.400">
          <Text fontSize="xs">{filtered.length} résultat(s)</Text>
        </HStack>
        <Button leftIcon={direction === 'entry' ? <LogIn size={17} /> : <LogOut size={17} />} onClick={openAdd}>
          {direction === 'entry' ? 'Nouvelle entrée' : 'Nouvelle sortie'}
        </Button>
      </Wrap>

      <DataTable
        columns={columns}
        data={filtered}
        pageSize={8}
        emptyMessage="Aucun mouvement enregistré."
        renderActions={(row) => (
          <HStack spacing={1}>
            <Tooltip label="Modifier" hasArrow>
              <IconButton aria-label="Modifier" icon={<Pencil size={16} />} size="sm" variant="ghost" onClick={() => openEdit(row)} />
            </Tooltip>
            <Tooltip label="Supprimer" hasArrow>
              <IconButton
                aria-label="Supprimer"
                icon={<Trash2 size={16} />}
                size="sm"
                variant="ghost"
                color="danger.500"
                _hover={{ bg: 'danger.50' }}
                onClick={() => askDelete(row)}
              />
            </Tooltip>
          </HStack>
        )}
      />

      <MovementFormModal
        isOpen={formModal.isOpen}
        onClose={formModal.onClose}
        onSubmit={handleSubmit}
        movement={selected}
        isSaving={isSaving}
        direction={direction}
        movementTypes={movementTypes}
      />

      <ConfirmDialog
        isOpen={deleteDialog.isOpen}
        onClose={deleteDialog.onClose}
        onConfirm={handleDelete}
        isLoading={isDeleting}
        title="Supprimer ce mouvement ?"
        message={toDelete ? `Voulez-vous vraiment supprimer l\u2019entrée de ${toDelete.prenom} ${toDelete.nom} du registre ?` : ''}
      />
    </Box>
  );
}

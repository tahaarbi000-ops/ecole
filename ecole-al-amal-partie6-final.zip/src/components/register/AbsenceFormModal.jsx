import { useEffect, useState } from 'react';
import { SimpleGrid, FormControl, FormLabel, FormErrorMessage, Input, Select, Button, Switch, HStack, Text } from '@chakra-ui/react';
import FormModal from '../common/FormModal';
import { levels } from '../../data/school';
import { absenceMotifs } from '../../data/register';

const EMPTY_FORM = { eleve: '', niveau: '', date: '', motif: '', justifiee: false };

export default function AbsenceFormModal({ isOpen, onClose, onSubmit, absence = null, isSaving = false }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});
  const isEditMode = Boolean(absence);

  useEffect(() => {
    if (isOpen) {
      setForm(absence ? { ...EMPTY_FORM, ...absence } : EMPTY_FORM);
      setErrors({});
    }
  }, [isOpen, absence]);

  const setField = (field) => (e) => {
    const value = e?.target ? e.target.value : e;
    setForm((f) => ({ ...f, [field]: value }));
  };

  const validate = () => {
    const next = {};
    if (!form.eleve.trim()) next.eleve = 'Le nom de l\u2019élève est requis.';
    if (!form.niveau) next.niveau = 'Le niveau est requis.';
    if (!form.date) next.date = 'La date est requise.';
    if (!form.motif) next.motif = 'Le motif est requis.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    onSubmit(form);
  };

  return (
    <FormModal
      isOpen={isOpen}
      onClose={onClose}
      title={isEditMode ? 'Modifier l\u2019absence' : 'Déclarer une absence'}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={handleSubmit} isLoading={isSaving} loadingText="Enregistrement…">
            {isEditMode ? 'Enregistrer' : 'Ajouter'}
          </Button>
        </>
      }
    >
      <form onSubmit={handleSubmit} noValidate>
        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
          <FormControl isInvalid={Boolean(errors.eleve)} isRequired gridColumn={{ md: 'span 2' }}>
            <FormLabel fontSize="sm">Élève</FormLabel>
            <Input value={form.eleve} onChange={setField('eleve')} placeholder="Yassine Jlassi" />
            <FormErrorMessage>{errors.eleve}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={Boolean(errors.niveau)} isRequired>
            <FormLabel fontSize="sm">Niveau</FormLabel>
            <Select placeholder="Sélectionner" value={form.niveau} onChange={setField('niveau')}>
              {levels.map((lvl) => (
                <option key={lvl} value={lvl}>{lvl}</option>
              ))}
            </Select>
            <FormErrorMessage>{errors.niveau}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={Boolean(errors.date)} isRequired>
            <FormLabel fontSize="sm">Date</FormLabel>
            <Input type="date" value={form.date} onChange={setField('date')} />
            <FormErrorMessage>{errors.date}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={Boolean(errors.motif)} isRequired>
            <FormLabel fontSize="sm">Motif</FormLabel>
            <Select placeholder="Sélectionner" value={form.motif} onChange={setField('motif')}>
              {absenceMotifs.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </Select>
            <FormErrorMessage>{errors.motif}</FormErrorMessage>
          </FormControl>

          <FormControl>
            <FormLabel fontSize="sm">Justification</FormLabel>
            <HStack h="40px" spacing={3}>
              <Switch colorScheme="blue" isChecked={form.justifiee} onChange={(e) => setField('justifiee')(e.target.checked)} />
              <Text fontSize="sm" color="ink.600">{form.justifiee ? 'Justifiée' : 'Non justifiée'}</Text>
            </HStack>
          </FormControl>
        </SimpleGrid>
      </form>
    </FormModal>
  );
}

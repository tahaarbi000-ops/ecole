import MovementPage from '../../components/register/MovementPage';
import { registerExits } from '../../data/register';

export default function Exits() {
  return <MovementPage direction="exit" initialData={registerExits} />;
}

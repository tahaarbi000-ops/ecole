import MovementPage from '../../components/register/MovementPage';
import { registerEntries } from '../../data/register';

export default function Entries() {
  return <MovementPage direction="entry" initialData={registerEntries} />;
}
